title: java-RunTime.getRunTime().addShutdownHook
date: '2019-09-06 10:37:57'
updated: '2019-09-06 10:40:48'
tags: [java, jvm]
permalink: /articles/2019/09/06/1567737476722.html
---
![](https://img.hacpai.com/bing/20180624.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

有时候我们用到的程序不一定总是在JVM里面驻守,可能调用完就不用了,释放资源.

RunTime.getRunTime().addShutdownHook的作用就是在JVM销毁前执行的一个线程.当然这个线程依然要自己写.

利用这个性质,如果我们之前定义了一系列的线程池供程序本身使用,那么就可以在这个最后执行的线程中把这些线程池优雅的关闭掉。第一次看到这中写法是在netty中代码如下
```java
Runtime.getRuntime().addShutdownHook(new Thread(chatServer::destroy));
```
因为netty中有不受jvm管控的内存资源，当jvm结束时这些内存不会自动释放会造成资源浪费，所以要手动释放。
