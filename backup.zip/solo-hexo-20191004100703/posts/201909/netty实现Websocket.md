title: netty-实现Websocket
date: '2019-09-04 17:43:03'
updated: '2019-09-19 09:30:12'
tags: [netty, 网络]
permalink: /articles/2019/09/04/1567590183516.html
---
![](https://img.hacpai.com/bing/20180624.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
 
# netty-实现Websocket


`netty` 提供了很多开箱即用的`ChannelHandler`其中就包括了`Websocket` 相关的`ChannelHandler` 只需要添加几行代码就可以完成对`Websocket` 的支持。
### WebSocketServerInitializer
```
public class WebSocketServerInitializer extends ChannelInitializer<SocketChannel> {
    @Override
    protected void initChannel(SocketChannel ch) throws Exception {
        ch.pipeline().addLast(
                new HttpServerCodec(),
                new HttpObjectAggregator(65536),
                new WebSocketServerCompressionHandler(),
                new WebSocketServerProtocolHandler("/websocket", null, true),
                new TextFrameHandler(),
                new BinaryFrameHandler(),
                new ContinuationFrameHandler());
    }
}
```
分别解释下各`Handler` 的作用
* `HttpServerCodec` `Http` 协议的解码编码器
* `HttpObjectAggregator` 聚合`Http` 消息，因为`Http`消息是多个部分组成想要业务层面处理的话要合并成一条完成的`Http`消息，`HttpObjectAggregator` 就是做这项工作的。
* `WebSocketServerCompressionHandler` 开启压缩传输这个`ChannelHanlder` 会在`Http` 响应头中添加
`Sec-websocket-extensions:permessage-deflate` 意思为和客户端协商启用压缩。
* `WebSocketServerProtocolHandler` 这个比较重要了就，它将接收到的握手包升级成`Websocket` 协议。构造函数第一个参数是`path` 意思就是客户端访问地址为`path` 时交给它去处理。
* `TextFrameHandler` 这个`Handler` 做的事情很简单处理接收到的文本消息帧将消息改为大写，`Websocket` 可以接收文本和二进制数据帧如果想要处理二进制数据帧可扩展为` SimpleChannelInboundHandler<BinaryWebSocketFrame>` 就可以完成相应的操作
```
public class TextFrameHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) throws Exception {
        ctx.writeAndFlush(new TextWebSocketFrame(msg.text().toUpperCase(Locale.US)));
    }
}

```
现在我们的`Netty` 就完成了对`WebSocket` 的支持，下面我们来写客户端代码
```
let ws = new WebSocket('ws://localhost:9090/websocket');
ws.onopen = function (ev) {
        console.log("onopen");
}
ws.onerror = function (ev) {
        console.log("error:",ev);
}
ws.onclose = function () {
        console.log("onclose")
}
ws.onmessage = function (msg) {
        console.log(msg.data);
}
```
客户`Api` 不再做解释相关说明[查看这篇文章](/articles/2019/09/04/1567573965089.html)
在浏览器中运行打开控制台测试下
![TIM截图20190919000038.png](https://img.hacpai.com/file/2019/09/TIM截图20190919000038-e6db161d.png)
可以看到服务端正确处理了数据，至此完成了客户端和服务端用`Websocket` 来交互的功能。这只是简单的使用后面文章会介绍更复杂的应用。
