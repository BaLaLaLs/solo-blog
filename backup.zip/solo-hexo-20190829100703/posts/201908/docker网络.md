title: docker 网络
date: '2019-08-28 23:26:46'
updated: '2019-08-28 23:38:37'
tags: [docker]
permalink: /articles/2019/08/28/1567006006561.html
---
docker 网络分为三种类型`bridge` `overlay` `host` 通过
```
docker network create
```
创建网络，-d 参数指定类型默认为`bridge` ,也可以启动镜像时指定 --network 参数 
```
docker run --network=xx
```
这样创建的网络为host类型
