title: 主流数据格式比较以及在netty中使用protobuf作为数据格式
date: '2019-10-06 21:02:51'
updated: '2019-10-07 00:46:06'
tags: [netty]
permalink: /articles/2019/10/06/1570366971756.html
---
![](https://img.hacpai.com/bing/20190926.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 数据载体的选择
* xml
* json
* protobuf

## xml
xml是一种最早的网络传输格式，常见于`Java web` 开发中，但它不单单作为网络层的数据传输格式，还常见于各种配置文件中，在移动开发中也常见但是已不是主流的网络传输格式，因为它的书写什么繁琐且不直观。例：
```xml
<?xml version="1.0" encoding="ISO-8859-1"?>
<book>
  <author>xx</author>
  <name>heihei</name>
  <iso>xxxxx</iso>
  <desc>this a very bored book</desc>
  <created_at>2019-10-12</created_at>
</book>
```
为了不占用太长的篇幅，这里贴出了最简单使用方式。这段代码描述了一个书的信息，可以看出代码是标签闭合式的风格这种写法的优点就是属性易扩展就像`html` 一样， 有着一定的可读性。其缺点也显而易见就是占用字节过多，这会导致在网络中传输时间加长。在早期互联网应用中应用广泛，现在几乎没有人在使用它来传输数据，现在主要用来描述配置文件。沙雕的微信支付还在用着这种远古的东西he pei。
### 总结
有着成熟的生态，各种语言基本都是对应的实现，~~发展多年稳定~~。前段时间爆出微信支付xml有漏洞还挺厉害的，要求所有对接支付的用户审查是否中招。沙雕微信:kissing:
## json
`JSON`(JavaScript Object Notation)一种轻量级的数据交换格式，是`ECMAScript` 制定的一种数据传输格式(就是那个制定javascript的组织)，使用完全独立于编程语言的**文本格式**来存储和表示数据，其特点是易于人阅读，解析，表达能力强。比`xml` 格式精简易读，适合用于网络传输。是**目前**大多数应用的选择。👆上面加粗文本格式字样是因为`json` 只适合用来描述文本数据对于二进制数据非常非常不推荐。例：
```
{
    "author": "xx",
    "name": "heihei",
    "iso": "123-23-21",
    "desc": "this a very bored book",
    "created_at": "2019-10-12"
}
```
### 总结
js 配合json使用特别方便，语言自带相关操作函数，其他语言也有丰富的库支持。推荐用它作为常规数据交互格式！
## protobuf
`Protocol Buffers` 是一种语言无关、平台无关、可扩展的序列化结构数据的方法，它可用于（数据）通信格式、数据存储等。Protocol Buffers 是一种灵活，高效，自动化机制的结构数据序列化方法－可类比 XML，但是比 XML 更小（3 ~ 10倍）、更快（20 ~ 100倍）、更为简单，目前版本是3。释义感觉和xml json 差不多，区别在于它很快它是二进制的它更小它更新。`xml` 和`json` 是文本格式的这就导致这两个注定不能用来传输多媒体资源，音乐，图片，视频。`protobuf` 有着丰富的数据类型可以很好的胜任这些工作。java proto文件：
```
syntax = "proto3";
option java_package = "com.example.xx";
option java_outer_classname = "MessageProtobuf";

message Msg {
    Head head = 1;
    string body = 2;
}
message Head {
    string msgId = 1;
    int32 msgType = 2;
    int32 msgContentType = 3;
    string fromId = 4;
    string toId = 5;
    int64 timestamp = 6;
    int32 statusReport = 7;
    string extend = 8;
}

```
### 实际操作使用

### 总结
`protobuf` 的应用场景是高性能复杂数据类型交互的场合，比如游戏后台服务，IM及时通讯。当然它也有缺点就是使用比较繁琐些，需要用工具来生成对应语言的数据结构。
