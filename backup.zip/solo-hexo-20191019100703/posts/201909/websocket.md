title: websocket
date: '2019-09-04 13:12:45'
updated: '2019-09-04 17:56:32'
tags: [网络]
permalink: /articles/2019/09/04/1567573965089.html
---
![](https://img.hacpai.com/file/2019/09/bg2017051501-d47bd024.png)

## WebSocket
`Websocket` 在9120年已经不是什么新技术了，为什么我还要写一篇文章来记录，之前只是简单的了解使用并没有深入的研究这个为千万网站带来革命的技术。
> [部分文字借鉴阮老师博客](http://www.ruanyifeng.com/blog/2017/05/websocket.html)
### 简介
WebSocket 协议在2008年诞生，2011年成为国际标准。所有浏览器都已经支持。
它的最大特点就是，服务器可以主动向客户端推送信息，客户端也可以主动向服务器发送信息，是真正的双向平等对话，属于[服务器推送技术](https://en.wikipedia.org/wiki/Push_technology)的一种。

其他特点包括：

（1）建立在 TCP 协议之上，服务器端的实现比较容易。

（2）与 HTTP 协议有着良好的兼容性。默认端口也是80和443，并且握手阶段采用 HTTP 协议，因此握手时不容易屏蔽，能通过各种 HTTP 代理服务器。

（3）数据格式比较轻量，性能开销小，通信高效。

（4）可以发送文本，也可以发送二进制数据。。

（5）没有同源限制，客户端可以与任意服务器通信。

（6）协议标识符是ws（如果加密，则为wss），服务器网址就是 URL。

```
ws://example.com:80/some/path
```
### 为什么使用websocket
---
让我们先看下如果没有`websocket`我们怎么实现
* 轮询
* 长轮询（常用）
* SSE(Server Send Event)
下面，我们对这几个都进行简单的介绍。
#### 轮询
轮询是最早在客户端用来模拟长连接的一种方式。他通过客户端定时想服务端发送HTTP请求来模拟客户端向服务端发送数据，而服务端的数据则是在客户端发送HTTP请求后跟随返回。

这种方案能够让客户端的数据几乎实时的到达，但是缺点也显而易见：服务端的数据需要在客户端的请求回来后才能带回。如果HTTP请求的间隔太短，则会导致大量的网络开销；如果间隔太长，这将导致数据传递的不及时。
#### 长轮询

长轮询是在轮询的基础上改进的一种方式。在客户端发送HTTP请求且服务端收到请求时，服务端会先维持这个请求不返回。在特定的时间内（一般为30秒，因为通常HTTP判断超时时间为30秒），如果服务端没有数据，则回应这个请求；服务端有数据需要发送时，则立即通过HTTP请求的响应将数据传递给客户端。客户端收到响应后，立即发起下一次的HTTP请求。

这种方案能够解决轮询中带来的服务端数据不能及时传递的问题，但是带来的网络花销大的问题仍然无法解决。

#### SSE(Server Send Event)
SSE是一个新的协议，作用为服务端想客户端推送数据。他通过自定义的SSE协议来实现单项的数据推送。SSE的缺点是数据只能从服务端像客户端传递，而数据不能通过客户端向服务端传递。

#### 小结
上面解决方案几乎都会增对服务器的带宽压力和网络压力，浪费的大量资源，对于程序来讲极为不可取。幸运的是`Websocket` 解决了上述所有问题。
1. 带宽问题：WebSocket相对于HTTP来说协议头更加小，同时按需传递。
2. 数据实时性问题：WebSocket相对于轮询和长轮询来说，能够实时传递数据，延迟更小。
3. 状态问题：相较于HTTP的无状态请求，WebSocket在建立连接后能够维持特定的状态。
### Websocket 协议解析
---
`WebSocket` 协议是通过HTTP协议升级而来。只需要在HTTP协议基础上增加握手，即可建立`WebSocket` 连接（如果是需要通过SSL加密，则还需要进行SSL握手过程, 具体我握手几次此处有争议个人觉得是一次验证之后补充），握手的部分详情可以见[WebSocket文档](https://tools.ietf.org/html/rfc6455#section-1.3)，下面我们简单介绍以下Header相关字段。
#### 握手请求Header
```
GET /chat HTTP/1.1
Host: server.example.com
Upgrade: websocket
Connection: Upgrade
Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==
Sec-WebSocket-Extensions: permessage-deflate
Origin: http://example.com
Sec-WebSocket-Version: 13
```
* `Host: server.example.com`：表示将要连接的WebSocket地址。
* `Connection: Upgrade`：需要升级HTTP连接。
* `Upgrade: websocket`：将HTTP连接升级至WebSocket连接。
* `Sec-WebSocket-Extensions: permessage-deflate`: 和服务端协商启用的扩展
* `Sec-WebSocket-Key:dGhlIHNhbXBsZSBub25jZQ== `：客户端生成的WebSocket连接密钥。
* `Sec-WebSocket-Version: 13`：WebSocket版本号。

#### 握手响应Header
```
HTTP/1.1 101 Switching Protocols
Upgrade: websocket
Connection: Upgrade
Sec-websocket-extensions:permessage-deflate
Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=
```
* `Upgrade: websocket`：确认将HTTP连接升级至WebSocket连接。
* `Connection: Upgrade`：确认升级HTTP连接。
* `Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo`：服务端根据客户端的连接密钥生成的服务端密钥。
* `Sec-WebSocket-Extensions: permessage-deflate`: 服务端支持`permessage-deflate`扩展

#### 数据传输
`Websocket`的数据传输是`frame` 形式传输的，比如会将一条消息分为几个`frame`，按照先后顺序传输出去。这样做会有几个好处：
* 大数据的传输可以分片传输，不用考虑到数据大小导致的长度标志位不足够的情况。
* 和http的chunk一样，可以边生成数据边传递消息，即提高传输效率。
### 客户端的 API
---
WebSocket 客户端的 API 如下。
#### WebSocket 构造函数WebSocket 对象作为一个构造函数，用于新建 WebSocket 实例。
```
var ws = new WebSocket('ws://localhost:8080');
```
执行上面语句之后，客户端就会与服务器进行连接。

实例对象的所有属性和方法清单，参见[这里](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)。
#### webSocket.readyState
---
`readyState`属性返回实例对象的当前状态，共有四种。
* CONNECTING：值为0，表示正在连接。  
* OPEN：值为1，表示连接成功，可以通信了。  
* CLOSING：值为2，表示连接正在关闭。  
* CLOSED：值为3，表示连接已经关闭，或者打开连接失败。
#### webSocket.onopen
实例对象的`onopen`属性，用于指定连接成功后的回调函数。

```javascript 
ws.onopen = function () {
  ws.send('Hello Server!');
}
```

如果要指定多个回调函数，可以使用`addEventListener`方法。
```javascript
ws.addEventListener('open', function (event) {
  ws.send('Hello Server!');
});
```
#### webSocket.onclose
---
实例对象的`onclose`属性，用于指定连接关闭后的回调函数。
```
ws.onclose = function(event) {
  var code = event.code;
  var reason = event.reason;
  var wasClean = event.wasClean;
  // handle close event
};

ws.addEventListener("close", function(event) {
  var code = event.code;
  var reason = event.reason;
  var wasClean = event.wasClean;
  // handle close event
});
```
#### webSocket.onmessage
---
实例对象的`onmessage`属性，用于指定收到服务器数据后的回调函数。
```
ws.onmessage = function(event) {
  var data = event.data;
  // 处理数据
};

ws.addEventListener("message", function(event) {
  var data = event.data;
  // 处理数据
});
```
注意，服务器数据可能是文本，也可能是二进制数据（`blob`对象或`Arraybuffer`对象）。
```
ws.onmessage = function(event){
  if(typeof event.data === String) {
    console.log("Received data string");
  }

  if(event.data instanceof ArrayBuffer){
    var buffer = event.data;
    console.log("Received arraybuffer");
  }
}
```
除了动态判断收到的数据类型，也可以使用`binaryType`属性，显式指定收到的二进制数据类型。
```
// 收到的是 blob 数据
ws.binaryType = "blob";
ws.onmessage = function(e) {
  console.log(e.data.size);
};

// 收到的是 ArrayBuffer 数据
ws.binaryType = "arraybuffer";
ws.onmessage = function(e) {
  console.log(e.data.byteLength);
};
```
#### webSocket.send()
---
实例对象的`send()`方法用于向服务器发送数据。

发送文本的例子。
```
var file = document
  .querySelector('input[type="file"]')
  .files[0];
ws.send(file);
```
发送 ArrayBuffer 对象的例子。
```
// Sending canvas ImageData as ArrayBuffer
var img = canvas_context.getImageData(0, 0, 400, 320);
var binary = new Uint8Array(img.data.length);
for (var i = 0; i < img.data.length; i++) {
  binary[i] = img.data[i];
}
ws.send(binary.buffer);
```
#### webSocket.bufferedAmount
实例对象的`bufferedAmount`属性，表示还有多少字节的二进制数据没有发送出去。它可以用来判断发送是否结束。
```
var data = new ArrayBuffer(10000000);
socket.send(data);

if (socket.bufferedAmount === 0) {
  // 发送完毕
} else {
  // 发送还没结束
}
```
#### webSocket.onerror
实例对象的`onerror`属性，用于指定报错时的回调函数。
```
socket.onerror = function(event) {
  // handle error event
};

socket.addEventListener("error", function(event) {
  // handle error event
});
```
### 服务器实现
关于服务器的实现选择有很多的比如
* `java netty`
* `node socket.io`
* `go gorilla/websocket`

根据个人爱好选择语言及库
我这里提供`java netty` 的实现供参考因为我最近在学习它:smile::smile:
[java netty websocket 实现](/articles/2019/09/04/1567590183516.html)


