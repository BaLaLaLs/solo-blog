title: netty-实现Websocket
date: '2019-09-04 17:43:03'
updated: '2019-09-13 22:48:11'
tags: [netty, 网络]
permalink: /articles/2019/09/04/1567590183516.html
---
![](https://img.hacpai.com/bing/20180624.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
 
# netty-实现Websocket


`netty` 提供了很多开箱即用的`Channel`其中就包括了`Websocket` 相关的`Channel` 只需要添加几行代码就可以完成对`Websocket` 的支持。
