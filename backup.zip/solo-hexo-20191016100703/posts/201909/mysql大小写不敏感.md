title: mysql 大小写不敏感
date: '2019-09-22 11:33:31'
updated: '2019-09-22 12:12:58'
tags: [mysql]
permalink: /articles/2019/09/22/1569123211554.html
---
![](https://img.hacpai.com/bing/20190402.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> 开发时没有留意到大小写不敏感这个问题，线上项目才发现数据畸形，程序也没有报什么错误，但是不保证之后不报错。如果项目中用到对字符串的比较比如java 的 `equals()` ，js `'a' == 'A'`。一定会导致数据错乱，我们应该杜绝这个可能性。
在MySQL中，数据库对应数据目录中的目录。数据库中的每个表至少对应数据库目录中的一个文件(也可能是多个，取决于存储引擎)。因此，所使用操作系统的大小写敏感性决定了数据库名和表名的大小写敏感性。  
    在大多数Unix中数据库名和表名对大小写敏感，而在Windows中对大小写不敏感。一个显著的例外情况是Mac OS X，它基于Unix但使用默认文件系统类型(HFS+)，对大小写不敏感。然而，Mac OS X也支持UFS卷，该卷对大小写敏感，就像Unix一样。
### MySQL大小写敏感的控制
控制大小写敏感关键的参数
查看自己电脑参数   
`show variables like 'lower%'`   
![image.png](https://img.hacpai.com/file/2019/09/image-b8d2fac5.png)
* ### lower_case_file_system 
说明是否数据目录所在的文件系统对文件名的大小写敏感，ON说明对文件名的大小写不敏感，OFF表示敏感。

* ### lower_case_table_names
`unix` 下`lower_case_table_names` 默认值为 0 .Windows下默认值是 1 .Mac OS X下默认值是 2。

| 参数值 | 解释 |  
| --- | --- |  
|  0|  使用CREATE TABLE或CREATE DATABASE语句指定的大小写字母在硬盘上保存表名和数据库名。名称比较对大小写敏感。在大小写不敏感的操作系统如windows或Mac OS x上我们不能将该参数设为0，如果在大小写不敏感的文件系统上将--lowercase-table-names强制设为0，并且使用不同的大小写访问MyISAM表名，可能会导致索引破坏。|  
|  1|  表名在硬盘上以小写保存，名称比较对大小写不敏感。MySQL将所有表名转换为小写在存储和查找表上。该行为也适合数据库名和表的别名。该值为Windows的默认值。 |  
|  2| 表名和数据库名在硬盘上使用CREATE TABLE或CREATE DATABASE语句指定的大小写字母进行保存，但MySQL将它们转换为小写在查找表上。名称比较对大小写不敏感，即按照大小写来保存，按照小写来比较。注释：只在对大小写不敏感的文件系统上适用! innodb表名用小写保存。 |

### 解决方案
1. 创建数据库时指定排序规则
* **_bin**: 表示的是binary case sensitive collation，也就是说是区分大小写。  
* **_ci**: case insensitive collation，不区分大小写 。
2. 修改字段
例：
```
alter table t1 modify name varchar(20) collate utf8_bin;
```
3. 查询时添加`binary` 关键字
```
SELECT * FROM test.a1 where binary name= 'a'
```
