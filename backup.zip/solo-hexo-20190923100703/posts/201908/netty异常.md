title: netty-异常
date: '2019-08-29 10:31:49'
updated: '2019-08-29 18:16:55'
tags: [netty]
permalink: /articles/2019/08/29/1567045908861.html
---
![](https://img3.doubanio.com/view/subject/l/public/s28361212.jpg)

## 处理异常
### 入站异常
* 如果是处理入栈事件异常，需要重写 `ChannelInboundHandler`中的 `exceptionCaught`方法, 该方法的默认					  实现是简单地将当前异常转发给 `ChannelPipeline`中的下一个 `ChannelHandler`
```java
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {                   
        cause.printStackTrace();
        ctx.close();
    }
```
因为异常将会继续按照入站方向流动，所以实现了异常处理的 `ChannelInboundHandler`通常位置 `ChannelPipeline`的最后, 这确保了所有的入站异常都总是会被处理，无论他们可能会发生在 `ChannelPipeline`中的什么位置。
* 异常达到了 `ChannelPipeline`尾端将会被视为未处理，netty会尝试释放该异常。
### 出站异常处理
* 出站操作都将会返回一个 `ChannelFuture`, 注册到 `ChannelFuture`的 `ChannelFutureListener` 将在操作完成时被通知成功了还是出错了。
* 几乎所有的 `ChannelOutboundHandler` 上的方法都会传入一个 `ChannelPromise` 对象，该类是`ChannelFuture` 的子类，但是它拥有立即通知的可写方法:
	```
	ChannelPromise setSuccess()
	ChannelPromise setFailure(Throwable cause)
	```

