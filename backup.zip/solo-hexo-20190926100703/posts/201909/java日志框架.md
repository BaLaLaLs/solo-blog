title: java日志框架
date: '2019-09-23 15:40:50'
updated: '2019-09-23 17:42:14'
tags: [java]
permalink: /articles/2019/09/23/1569224449937.html
---
![](https://img.hacpai.com/bing/20180510.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

java 的日志框架有以下几个主流框架
*  `log4j`
Log4J 是 Apache 的一个日志开源框架，有多个分级（DEBUG/INFO/WARN/ERROR）记录级别，可以很好地将不同日志级别的日志分开记录，极大地方便了日志的查看。
* `logback`
logback其实可以说是 Log4J 的进化版，因为它们两个都是同一个作者（Ceki Gülcü）设计的开源日志组件。logback除了具备 Log4j 的所有优点之外，还解决了 Log4J 不能使用占位符的问题。
> `logback` 有三个包,分别负责不同的功能
```
logback-core:提供了LogBack的核心功能，是另外两个组件的基础。   
logback-classic:实现了Slf4j的API，所以当想配合Slf4j使用时，需要引入logback-classic。   
logback-access:为了集成Servlet环境而准备的，可提供HTTP-access的日志接口。
```
* `SLF4J`
`SLF4J` 比较特殊它没有具体的日志api实现，只有标准定义。主要作用是抽象各日志框架的api，比如项目一开始使用的日志框架为`log4j`，后面发现`log4j` 不能完成项目要求需要更换为`logback` 框架这时比较头疼的问题就出现了，如果没有`SLF4J` 我们要一行一行的将`log4j`的代码替换为`logback`代码，工作量巨大又容易出错。`SLF4J`的出现解决了这个问题，项目一开始就使用`SLF4J` 配合任意一个日志框架，后面无论底层的日志框架怎么更换都不会影响到现有代码结构。
