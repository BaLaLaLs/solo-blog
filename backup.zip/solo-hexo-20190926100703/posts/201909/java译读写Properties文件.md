title: java [译]读写Properties 文件
date: '2019-09-23 18:16:44'
updated: '2019-09-25 00:24:42'
tags: [java]
permalink: /articles/2019/09/23/1569233804700.html
---
项目中用到了配置文件百度Java操作Properties 文件的文章没有发现比较好的文章在`google` 上看到了一篇写的很通俗易懂的文章，鉴于国内很多小伙伴的网络环境可能打不开google想着就把它拿来翻译下。原文
> https://www.mkyong.com/java/java-properties-file-examples/

一般, `.properties` 文件是用来储存应用配置的。在这个教程中，在这个教程中我们将展示如何读写 `.properties` 文件.
```
Properties prop = new Properties();
	
// set key and value
prop.setProperty("db.url", "localhost");
prop.setProperty("db.user", "mkyong");
prop.setProperty("db.password", "password");
	
// save a properties file
prop.store(outputStream, "");

// load a properties file
prop.load(inputStream)

// get value by key
prop.getProperty("db.url");
prop.getProperty("db.user");
prop.getProperty("db.password");

// get all keys
prop.keySet();
	
// print everything
prop.forEach((k, v) -> System.out.println("Key : " + k + ", Value : " + v));

```
用来测试的`Maven`项目结构。
![javapropertiesfile.png](https://img.hacpai.com/file/2019/09/javapropertiesfile-25ece98a.png)

## 写 properties file
设置键和值，并且在某处保存。
```
package com.mkyong;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class App1 {
    public static void main(String[] args) {

        try (OutputStream output = new FileOutputStream("D:/config.properties")) {

            Properties prop = new Properties();

            // set the properties value
            prop.setProperty("db.url", "localhost");
            prop.setProperty("db.user", "mkyong");
            prop.setProperty("db.password", "password");

            // save properties to project root folder
            prop.store(output, null);

            System.out.println(prop);
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
}

```
输出
```
{db.user=mkyong, db.password=password, db.url=localhost}
``` 
`D:/config.properties` 文件就创建出来了
```
#Thu Apr 11 17:37:58 SRET 2019
db.user=mkyong
db.password=password
db.url=localhost
```
## 读取 properties 文件
从文件系统读取`properties` 文件并检索属性值
```
package com.mkyong;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class App2 {

    public static void main(String[] args) {

        try (InputStream input = new FileInputStream("D:/config.properties")) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            System.out.println(prop.getProperty("db.url"));
            System.out.println(prop.getProperty("db.user"));
            System.out.println(prop.getProperty("db.password"));

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

}
```
输出
```
localhost
mkyong
password
```

##  从classpath 加载`properties` 文件
从项目的`classpath` 中加载`config.properties`，并检索值
`config.properties` 内容：
```
db.url=localhost
db.user=mkyong
db.password=passwor

```
```
package com.mkyong;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class App3 {

    public static void main(String[] args) {

        try (InputStream input = App3.class.getClassLoader().getResourceAsStream("config.properties")) {

            Properties prop = new Properties();

            if (input == null) {
                System.out.println("Sorry, unable to find config.properties");
                return;
            }

            //load a properties file from class path, inside static method
            prop.load(input);

            //get the property value and print it out
            System.out.println(prop.getProperty("db.url"));
            System.out.println(prop.getProperty("db.user"));
            System.out.println(prop.getProperty("db.password"));

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

}

```
输出
```
localhost
mkyong
password
```

## 从properties文件中打印所有键值
从`classpath` 中加载`config.properties`，打印所有键和值
```
package com.mkyong;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

public class App4 {

    public static void main(String[] args) {
        App4 app = new App4();
        app.printAll("config.properties");
    }

    private void printAll(String filename) {

        try (InputStream input = getClass().getClassLoader().getResourceAsStream(filename)) {

            Properties prop = new Properties();

            if (input == null) {
                System.out.println("Sorry, unable to find " + filename);
                return;
            }

            prop.load(input);

            // Java 8 , print key and values
            prop.forEach((key, value) -> System.out.println("Key : " + key + ", Value : " + value));

            // Get all keys
            prop.keySet().forEach(x -> System.out.println(x));

            Set<Object> objects = prop.keySet();

            /*Enumeration e = prop.propertyNames();
            while (e.hasMoreElements()) {
                String key = (String) e.nextElement();
                String value = prop.getProperty(key);
                System.out.println("Key : " + key + ", Value : " + value);
            }*/

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

}

```
输出
```
Key : db.user, Value : mkyong
Key : db.password, Value : password
Key : db.url, Value : localhost
db.user
db.password
db.url
```
## 总结
从上代码看出java操作`properties` 文件十分方便，官方给封装了工具类。项目中的配置建议都用这种方式存储，它的表达能力比`xml`文件强， 还比较好操作，是个不错的文件配置解决方案。
