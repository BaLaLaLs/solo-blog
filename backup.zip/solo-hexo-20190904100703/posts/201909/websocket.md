title: websocket
date: '2019-09-03 18:17:27'
updated: '2019-09-03 18:17:27'
tags: [网络]
permalink: /articles/2019/09/03/1567505847040.html
---
![](https://img.hacpai.com/bing/20190205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

test
